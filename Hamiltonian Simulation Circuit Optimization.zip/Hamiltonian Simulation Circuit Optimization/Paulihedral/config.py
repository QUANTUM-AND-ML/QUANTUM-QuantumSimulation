# The config file
# test_scale: specify the benchmark size you want to test
# 'small': only contains small benchmarks.
# 'full': if you want to run all benchmarks.
test_scale = 'small'
